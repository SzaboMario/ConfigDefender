﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        StreamWriter sw;
        private bool run;
        readonly string lastModificationFileInfo = "files.txt";
        readonly string savedFileBackups = "Backup\\";
        readonly string logFile = "Log.txt";
        Dictionary<string, string> fileInfos;

        Thread thread;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            WriteLog("Program started.");
            fileInfos = new Dictionary<string, string>();
            if (File.Exists(lastModificationFileInfo))//ha van file betölti a modification file-t
            {
                using (StreamReader sr = new StreamReader(lastModificationFileInfo))
                {
                    WriteLog($"Loading {lastModificationFileInfo}:");
                    string[] line;
                    while (!sr.EndOfStream)
                    {
                        line = sr.ReadLine().Split('=');
                        fileInfos.Add(line[0], line[1]);
                        WriteLog($"{line[0]}-{line[1]}");
                    }
                    sr.Close();
                    WriteLog($"Loading {lastModificationFileInfo} is complete.");
                }

                if (fileInfos.Count > 0 && Directory.Exists(savedFileBackups))//ha van backup mappa, akkor betölti
                {
                    WriteLog($"Loading {savedFileBackups}:");
                    string[] filesInFolder = Directory.GetFiles(savedFileBackups);

                    for (int d = 0; d < filesInFolder.Length; d++)
                    {
                        if (fileInfos.ContainsKey(filesInFolder[d]))
                        {
                            WriteLog($"{lastModificationFileInfo} contains {filesInFolder[d]} ->OK");
                        }
                        else
                        {
                            WriteLog($"{lastModificationFileInfo} not contains {filesInFolder[d]} ->NG");
                        }
                    }
                }
                WriteLog($"Loading completed.");
            }
            else
            {             
                File.Create(lastModificationFileInfo);
                WriteLog($"{lastModificationFileInfo} file created.");
            }
        }

        private void WriteLog(string data)
        {
            try
            {
                using (StreamWriter wr = new StreamWriter(logFile, true))
                {
                    wr.WriteLine($"- {DateTime.Now}: {data}");
                    wr.Flush();
                    wr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
            }

        }

        private void fileSelectBtn_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                foreach (var item in openFileDialog1.FileNames)
                {
                    listBox.Items.Add(item);
                }

            }

        }

        private void CheckerThread()
        {
            while (run)
            {
                if (listBox.Items.Count > 0)
                {

                }
                Thread.Sleep(1000);
            }
        }

        private void startBtn_Click(object sender, EventArgs e)
        {
            if (!run)
            {
                Start();
            }
            else
            {
                Stop();
            }

        }

        private void Start()
        {
            thread = new Thread(new ThreadStart(CheckerThread));
            thread.IsBackground = true;
            run = true;
            thread.Start();
        }
        private void Stop()
        {
            run = false;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            run = false;
            using (StreamWriter sr= new StreamWriter(lastModificationFileInfo,false))
            {
                if (listBox.Items.Count==0)
                {
                    WriteLog("Zero file info saved.");
                }
                else
                {
                    foreach (string item in listBox.Items)
                    {
                        sr.WriteLine($"{item}={File.GetLastWriteTime(item)}");
                        if (item != "")
                        {
                            WriteLog($"Saved {item}={File.GetLastWriteTime(item)} to {lastModificationFileInfo}");
                        }
                    }

                    sr.Flush();
                    sr.Close();
                    WriteLog("Save complete.");
                }
               
               
            }
            WriteLog("Program exit.");
        }
    }
}
