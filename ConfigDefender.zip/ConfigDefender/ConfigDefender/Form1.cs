﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfigDefender
{
    public partial class Form1 : Form
    {
        StreamWriter sw;
        private bool run;
       public readonly string filesTxT = "files.txt";
        public readonly string backupFolder = "ConfigBackup";
        readonly string logTxt = "Log.txt";
        Dictionary<string, string> fileInfos;
        Thread thread;
        Core core;
        internal string[] fileNamesFromFolderArr;
        internal List<string[]> fileDataList;


        public Form1()
        {
            InitializeComponent();
            core = new Core(this);
            this.notifyIcon1.ContextMenuStrip = new System.Windows.Forms.ContextMenuStrip();
            this.notifyIcon1.ContextMenuStrip.Items.Add("Open", null, this.MenuOpen_Click);
            this.notifyIcon1.ContextMenuStrip.Items.Add("Exit", null, this.MenuExit_Click);
        }

        private void MenuExit_Click(object sender, EventArgs e)
        {
            run = false;
            Environment.Exit(0);
        }

        private void MenuOpen_Click(object sender, EventArgs e)
        {
            notifyIcon1.Visible = false;
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {        
            if (this.WindowState == FormWindowState.Minimized)
            {
                notifyIcon1.Icon = this.Icon;
                notifyIcon1.Text = "ConfigDefender";
                notifyIcon1.Visible = true;            
                this.Hide();
            }
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {

        }




        private void Form1_Load(object sender, EventArgs e)
        {//indításkori ellenőrzés
            core.WriteLog("==========Program started==========");             
            fileDataList=core.GetFileData(filesTxT);//ha létezik, akkor betölti az adatokat            
            fileNamesFromFolderArr = core.GetFileNamesFromFolder(backupFolder);//ha van akkor betőlti a fájlok nevét         
            core.SetDataToListBox(fileDataList);
            core.CompareFileNames(fileDataList, fileNamesFromFolderArr);//adatok összehasonlítása




           
        }

        internal void AddSelectedFileToListBox(string[] fileArray)
        {
            if (listBox.Items.Count==0)
            {
                foreach (var item in fileArray)
                {
                    listBox.Items.Add(item);
                }
            }
            else
            {
                foreach (string it in fileArray)
                {
                    if (!listBox.Items.Contains(it))
                    {
                        listBox.Items.Add(it);
                    }
                }
            }

        }

        private void addFileBtn_Click(object sender, EventArgs e)
        {
            DialogResult dr = openFileDialog1.ShowDialog();

            if (dr == DialogResult.OK)
            {
                AddSelectedFileToListBox(openFileDialog1.FileNames);        
            }
            if (dr == DialogResult.Cancel)
            {
                listBox.Items.Clear();
            }
            core.SaveListBoxDataToFile();
        }

      

        private void startBtn_Click(object sender, EventArgs e)
        {
            core.StartStop();
        }

       

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            notifyIcon1.Visible = false;
            notifyIcon1.Dispose();
            run = false;
            core.WriteLog("==========Program exit==========");
        }


       

        private void listClearBtn_Click(object sender, EventArgs e)
        {
            using (PassForm pf = new PassForm())
            {
                if (pf.ShowDialog() == DialogResult.OK)
                {
                    if (pf.textBox1.Text == "vision")
                    {
                        listBox.Items.Clear();
                    }
                    else
                    {
                        core.WriteLog($"Wrong password, when user try delete listBox items({pf.textBox1.Text})");
                    }
                }
            }
        }

        private void deleteSelectedBtn_Click(object sender, EventArgs e)
        {
            using (PassForm pf = new PassForm())
            {
                if (pf.ShowDialog() == DialogResult.OK)
                {
                    if (pf.textBox1.Text == "vision")
                    {
                        while (listBox.SelectedItems.Count > 0)
                        {
                            core.WriteLog($"Removed selected files from program list(not original folder):{listBox.SelectedItems[0]}");
                            listBox.Items.Remove(listBox.SelectedItems[0]);                           
                        } 
                    }
                    else
                    {
                        core.WriteLog($"Wrong password, when user try delete listBox item({pf.textBox1.Text})");
                    }
                }
            }
        }

        private void notifyIcon1_BalloonTipClosed(object sender, EventArgs e)
        {
          
        }
    }
}
