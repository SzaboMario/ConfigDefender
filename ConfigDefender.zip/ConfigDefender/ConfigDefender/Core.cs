﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfigDefender
{
    class Core
    {

        StreamWriter sw;
        private bool run;
        bool startStop = false;
        readonly string logTxt = "Log.txt";

        Form1 form;
        Thread thread;
        
        public Core(Form form1)
        {
            form = (Form1)form1;
        }


        internal List<string[]> GetFileData(string filesTxT)
        {
            List<string[]> fileList = new List<string[]>();
            if (FilesTextFileIsExists(filesTxT))
            {                
                string[] lineArr = null;
                using (StreamReader sr = new StreamReader(filesTxT))
                {
                    WriteLog($"Loading {filesTxT}:");
                    while (!sr.EndOfStream)
                    {
                        lineArr = sr.ReadLine().Split('=');
                        fileList.Add(lineArr);
                    }
                    sr.Close();                                  
                }
            }
            if (fileList.Count == 0) { WriteLog($"{filesTxT} is empty."); }
            WriteLog($"Loading {filesTxT} is complete.");
            return fileList;
        }

        internal string[] GetFileNamesFromFolder(string folderName)
        {
            string[] files = null;
            if (BackupFolderIsExist(folderName))
            {              
                files= Directory.GetFiles(form.backupFolder, "*.*", SearchOption.AllDirectories);//backupfolderból fájlok beolvasása
            }
            else
            {              
                files = new string[0];
            }
            if(files.Length>0) WriteLog($"Files from {folderName} loaded.");
            else WriteLog($"{folderName} folder is empty.");
            return files;
        }


        internal bool CompareFileNames(List<string[]> fileDataList, string[] fileNamesFromFolderArr)
        {
            string filename="";
            string fullFileName = "";
            List<string> deletedData = new List<string>();
            List<string> tmp = new List<string>();
            try
            {
                foreach (string it in fileNamesFromFolderArr)
                {
                    tmp.Add(it.Substring(it.LastIndexOf("\\") + 1));
                }
                foreach (string[] item in fileDataList)
                {
                    fullFileName = item[0];
                    filename = fullFileName.Substring(fullFileName.LastIndexOf("\\") + 1);
                    if (!tmp.Contains(filename))//ha a lista nem tartalmazza a backup file-t
                    {
                        DialogResult res = MessageBox.Show(null, $"The Backup folder does not contain the {fullFileName}.\nDo you want to save to the Backup folder?\n(If not, this data will be deleted from the files.txt).)", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);//ha nem található fájl a backup mappában
                        if (res == DialogResult.Yes)
                        {
                            if (File.Exists(fullFileName))
                            {
                                File.Copy(fullFileName, form.backupFolder+"\\"+filename, true);
                                WriteLog($"{fullFileName} file copied to Backup folder by user.");
                            }
                            else
                            {
                                WriteLog($"{fullFileName} file not found!");
                            }
                        }
                        else if (res == DialogResult.No)
                        {
                            deletedData.Add(fullFileName);
                            WriteLog($"{fullFileName}  deleted from files.txt by user.");
                        }
                    }

                }
                if (deletedData.Count>0)
                {
                    foreach (string item in deletedData)
                    {
                        fileDataList.RemoveAll(x => x[0] == item);                      
                    }
                    SetDataToListBox(fileDataList);
                    SaveListBoxDataToFile();
                }


                      
            }
            catch (Exception ex)
            {
                MessageBox.Show("CompareFilesAndData: " + ex.Message+"\n"+ex.StackTrace);
                return false;
            }
            return true;
        }






        internal void SetDataToListBox(List<string[]> fileDataList)
        {
            form.listBox.Items.Clear();
            if (fileDataList!=null&&fileDataList.Count > 0) 
            {
                foreach (var item in fileDataList)
                {
                    form.listBox.Items.Add(item[0]);
                }
                WriteLog($"ListBox data loading in OK.");
            } 
        }
        
        internal bool FilesTextFileIsExists( string fileName)
        {
            if (!File.Exists(fileName))
            {            
                WriteLog($"The {fileName} does not exist -> Create new one.");
                File.Create(fileName).Close();
                WriteLog($"{fileName} created!");
            }
            WriteLog($"The {fileName} is exists");
            return true;
        }

        internal bool BackupFolderIsExist(string folderName)
        {
            if (!Directory.Exists(folderName))
            {
                WriteLog($"The {folderName} does not exist -> Create new one.");
                Directory.CreateDirectory(folderName);
                WriteLog($"{folderName} created!");
            }           
            WriteLog($"The {folderName} is exists");
            return true;
        }

 


        internal void WriteLog(string data)
        {
            try
            {
                using (StreamWriter wr = new StreamWriter(logTxt, true))
                {
                    wr.WriteLine($"- {DateTime.Now}: {data}");
                    wr.Flush();
                    wr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("WriteLog: " + ex.Message + "\n" + ex.StackTrace);
            }
        }


       internal void CheckerThread()
        {
            bool res = false;
            int notFindCounter = 0;
            List<string> firstFileList = new List<string>(), secFileList = new List<string>();
            while (run)
            {
                if (form.listBox.Items.Count > 0)
                {
                    foreach (string item in form.listBox.Items)
                    {
                        firstFileList.Clear();
                        secFileList.Clear();
                        if (!File.Exists(item))
                        {
                            WriteLog($"Not find file: {item}");
                            notFindCounter++;
                            if (notFindCounter == 20)
                            {
                                MessageBox.Show($"Not find file: {item}");
                                notFindCounter = 0;
                            }
                        }
                        else
                        {
                            firstFileList = GetConfigDataFromFile(item);
                            secFileList = GetConfigDataFromFile(form.backupFolder+"\\"+item.Substring(item.LastIndexOf("\\")+1));
                            if (firstFileList.Count>0&& secFileList.Count>0&& firstFileList.Count== secFileList.Count)
                            {
                                res = CompareFileDatas(item, firstFileList, form.backupFolder + "\\" + item.Substring(item.LastIndexOf("\\") + 1), secFileList);
                            }
                            else   MessageBox.Show("Comparable files not find or not same line numbers.");
                        }
                    }
                   
                }
                Thread.Sleep(2000);
            }
        }

        private bool CompareFileDatas(string fFileName, List<string> firstFile, string sFileName, List<string> secFile)
        {
            if (DateTime.Parse(File.GetLastWriteTime(fFileName).ToString()) != DateTime.Parse(File.GetLastWriteTime(sFileName).ToString()))
            {
                for (int first = 0; first < firstFile.Count; first++)
                {
                    if (firstFile[first] != secFile[first])
                    {
                        UpdateBackupFile(sFileName, firstFile[first], secFile[first]);
                        WriteLog($"\n" +
                            $"------------------------\n" +
                            $"Not same data in {fFileName}:\n" +
                            $"Checked file data: -> {firstFile[first]}\n" +
                            $"Backup file data:  -> {secFile[first]}\n" +
                            $"Old param({secFile[first]}) in {sFileName} updated to {firstFile[first]}\n" +
                            $"------------------------");
                    }   
                }           
                return false;
            }
            return true;
        }

        private void UpdateBackupFile(string fileName,string oldParam,string newParam)
        {
            try
            {
                string[] lines = System.IO.File.ReadAllLines(fileName);
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i] == newParam)
                    {
                        lines[i] = oldParam;
                    }
                }
                System.IO.File.WriteAllLines(fileName, lines);
                
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("WriteLog: " + ex.Message + "\n" + ex.StackTrace); throw;
            }
            
        }

        internal List<string> GetConfigDataFromFile(string fileName)
        {
            List<string> tmp = new List<string>();
            try
            {             
                if (File.Exists(fileName))
                {
                    using (StreamReader sr = new StreamReader(fileName))
                    {
                        while (!sr.EndOfStream)
                        {
                            tmp.Add(sr.ReadLine());
                        }
                        sr.Close();
                    }
                }
                else
                {
                    DialogResult res= MessageBox.Show(null, $"Not find {fileName} file!", "ERROR",MessageBoxButtons.YesNo,MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"GetConfigDataFromFile:\n{ex.Message}\n{ex.StackTrace}");
            }
            return tmp;
        }

        internal void StartStop()
        {
            using (PassForm pf = new PassForm())
            {
                if (form.listBox.Items.Count>0&&pf.ShowDialog() == DialogResult.OK)
                {
                    if (pf.textBox1.Text == "vision")
                    {
                        if (!startStop)
                        {
                            startStop = !startStop;
                            thread = new Thread(new ThreadStart(CheckerThread));
                            thread.IsBackground = true;
                            run = true;
                            thread.Start();
                            WriteLog("Strarted");
                            form.startBtn.Text = "Started";
                            form.startBtn.BackColor = Color.LightGreen;
                            form.addFileBtn.Enabled = false;
                            form.listClearBtn.Enabled = false;
                            form.deleteSelectedBtn.Enabled = false;
                        }
                        else
                        {
                            startStop = !startStop;
                            run = false;
                            WriteLog("Stopped");
                            form.startBtn.Text = "Stopped";
                            form.startBtn.BackColor = Color.Tomato;
                            form.addFileBtn.Enabled = true;
                            form.listClearBtn.Enabled = true;
                            form.deleteSelectedBtn.Enabled = true;
                        }                     
                    }
                    else
                    {
                        WriteLog($"Wrong password, when user try delete listBox({pf.textBox1.Text})");
                    }
                }
            }
        }


        
        internal void SaveListBoxDataToFile()
        {
            try
            {
                if (form.listBox.Items.Count == 0)
                {
                    try
                    {
                        File.Delete(form.filesTxT);
                        FileStream fs = File.Create(form.filesTxT);
                        fs.Close();
                        WriteLog("files.txt clear OK.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                    }
                }
                else
                {
                    using (StreamWriter sr = new StreamWriter(form.filesTxT, false))
                    {
                        foreach (string item in form.listBox.Items)
                        {
                            sr.WriteLine($"{item}={File.GetLastWriteTime(item)}");
                            if (item != "")
                            {
                                WriteLog($"Saved from program: {item}={File.GetLastWriteTime(item)} to {form.filesTxT}");
                                if (!Directory.Exists(form.backupFolder))
                                {
                                    Directory.CreateDirectory(form.backupFolder);
                                }
                                if (File.Exists(item)) File.Copy(item, form.backupFolder + "\\" + item.Substring(item.LastIndexOf("\\") + 1), true);
                                else { WriteLog($"Not find file: {item}"); form.listBox.Items.Remove(item); }
                            }
                        }
                        sr.Flush();
                        sr.Close();
                        WriteLog("File write to "+ form.backupFolder + " complete.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("SaveListBoxDataToFile: " + ex.Message + "\n" + ex.StackTrace);
            }
        }

      /*  internal void DeleteSelectedData()
        {
            if (form.listBox.Items.Count > 0)
            {
                List<string> tmp = new List<string>();
                foreach (string item in form.listBox.Items)
                {
                    tmp.Add(item);
                }             
                foreach (var i in form.listBox.SelectedItems)
                {
                    tmp.Remove(i.ToString());
                }
                form.listBox.Items.Clear();
                form.listBox.Items.AddRange(tmp.ToArray());
                SaveListBoxDataToFile();
                WriteLog("Delete selected items: OK");
            }
            
        }*/

    }
}
